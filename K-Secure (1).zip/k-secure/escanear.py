"""Escanea uno o más archivos desde la terminal y genera el reporte de clasificación.

Uso:
    python escanear.py examples/sample_data.csv
    python escanear.py informe.docx planilla.xlsx --salida output
"""

import argparse
from pathlib import Path

from ksecure.report import ClassificationReport
from ksecure.scanner import KSecureScanner


def main():
    parser = argparse.ArgumentParser(description="Escáner de datos sensibles K-Secure")
    parser.add_argument("archivos", nargs="+", help="Archivos a escanear (csv, txt, docx, xlsx, pptx, pdf)")
    parser.add_argument("--salida", default="output", help="Carpeta donde guardar reporte.json y reporte.csv")
    args = parser.parse_args()

    findings = KSecureScanner().scan_many(args.archivos)
    reporte = ClassificationReport(findings)
    print(reporte.to_console())

    salida = Path(args.salida)
    salida.mkdir(exist_ok=True)
    reporte.to_json(salida / "reporte.json")
    reporte.to_csv(salida / "reporte.csv")
    print(f"\nReportes guardados en {salida / 'reporte.json'} y {salida / 'reporte.csv'}")


if __name__ == "__main__":
    main()
