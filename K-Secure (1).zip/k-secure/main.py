"""API y dashboard de K-Secure."""

import logging
import shutil
import time
import uuid
from collections import defaultdict
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from ksecure import archivos
from ksecure import db_service as svc
from ksecure.conexiones import TIPOS_BD, ConexionError, DatosConexion, crear_engine, leer_valor
from ksecure.database import Base, engine as engine_interno, get_db
from ksecure.db_models import Escaneo, Hallazgo
from ksecure.migraciones import migrar
from ksecure.paths import data_dir, resource_dir
from ksecure.scanner import SUPPORTED_EXTENSIONS, KSecureScanner, UnsupportedFormatError

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
audit_log = logging.getLogger("ksecure.auditoria")

MAX_DOCUMENTO_BYTES = 20 * 1024 * 1024          # 20 MB (documentos, CSV y Excel)
EXTENSIONES_BD = {".db", ".sqlite", ".sqlite3"}
FILAS_MAX_DEFECTO = 10_000

# Protección contra fuerza bruta en /api/unmask
MAX_INTENTOS_FALLIDOS = 5
BLOQUEO_SEGUNDOS = 60
_intentos_fallidos: dict[str, list[float]] = defaultdict(list)

# Conexiones abiertas en esta sesión (escaneo_id -> engine). Viven solo en memoria:
# al cerrar K-Secure se pierden y para desenmascarar hay que volver a conectar.
_conexiones_activas: dict[int, Engine] = {}

app = FastAPI(title="K-Secure")
Base.metadata.create_all(bind=engine_interno)
migrar(engine_interno)  # actualiza bases internas creadas por versiones anteriores
scanner = KSecureScanner()


# --------------------------------------------------------------------------- #
# Página y configuración inicial
# --------------------------------------------------------------------------- #
@app.get("/")
def read_root():
    return FileResponse(resource_dir() / "index.html")


@app.get("/api/estado")
def estado(db: Session = Depends(get_db)):
    return {"configurado": svc.hay_clave_auditor(db), "tipos_bd": TIPOS_BD}


class ClaveRequest(BaseModel):
    password: str = Field(min_length=6)


@app.post("/api/configurar")
def configurar(req: ClaveRequest, db: Session = Depends(get_db)):
    """Primer uso: define la contraseña de auditor. No se puede sobrescribir desde aquí."""
    if svc.hay_clave_auditor(db):
        raise HTTPException(status_code=409, detail="La contraseña de auditor ya fue configurada.")
    svc.definir_clave_auditor(db, req.password)
    return {"ok": True}


# --------------------------------------------------------------------------- #
# Escaneo de bases de datos del cliente
# --------------------------------------------------------------------------- #
class ConexionRequest(BaseModel):
    tipo: str
    ruta: str = ""
    host: str = "localhost"
    puerto: Optional[int] = None
    base: str = ""
    usuario: str = ""
    password: str = ""
    max_filas: int = Field(default=FILAS_MAX_DEFECTO, ge=1, le=1_000_000)


def _escanear_engine(db: Session, engine: Engine, descripcion: str, max_filas: int,
                     formato: str = "servidor", ruta_local: Optional[str] = None) -> dict:
    t0 = time.time()
    escaneo = svc.guardar_escaneo_bd(db, engine, descripcion, scanner, max_filas, formato, ruta_local)
    _conexiones_activas[escaneo.id] = engine
    logging.info("Escaneo %s de '%s' en %.1fs", escaneo.id, descripcion, time.time() - t0)
    return svc.escaneo_a_dict(db, escaneo)


@app.post("/api/bd/probar")
def probar_conexion(req: ConexionRequest):
    from ksecure.conexiones import listar_tablas

    datos = DatosConexion(**req.model_dump(exclude={"max_filas"}))
    try:
        engine = crear_engine(datos)
    except ConexionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    try:
        tablas = listar_tablas(engine)
    finally:
        engine.dispose()
    return {"ok": True, "tablas": tablas}


@app.post("/api/bd/escanear")
def escanear_bd(req: ConexionRequest, db: Session = Depends(get_db)):
    datos = DatosConexion(**req.model_dump(exclude={"max_filas"}))
    try:
        engine = crear_engine(datos)
    except ConexionError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if datos.tipo == "sqlite":
        # Archivo del usuario: se puede reabrir para desenmascarar mientras exista
        return _escanear_engine(db, engine, datos.descripcion(), req.max_filas,
                                "sqlite", str(Path(datos.ruta.strip().strip('"')).resolve()))
    return _escanear_engine(db, engine, datos.descripcion(), req.max_filas)


# --------------------------------------------------------------------------- #
# Subida de archivos
#   .db/.sqlite      -> se escanea como base de datos
#   .csv/.xlsx/.xls  -> se convierte en tabla y se escanea como base de datos
#   docx/pdf/pptx/txt -> se escanea como documento
# En todos los casos queda una copia local para poder desenmascarar.
# --------------------------------------------------------------------------- #
@app.post("/api/scan")
async def scan_archivo(
    file: UploadFile = File(...),
    max_filas: int = Form(FILAS_MAX_DEFECTO),
    db: Session = Depends(get_db),
):
    nombre = Path(file.filename or "archivo").name
    extension = Path(nombre).suffix.lower()

    if extension in EXTENSIONES_BD:
        destino = archivos.ruta_nueva(nombre)
        with destino.open("wb") as fh:
            shutil.copyfileobj(file.file, fh)
        with destino.open("rb") as fh:
            if fh.read(16) != b"SQLite format 3\x00":
                destino.unlink(missing_ok=True)
                raise HTTPException(status_code=400, detail="El archivo no es una base de datos SQLite válida.")
        try:
            engine = crear_engine(DatosConexion(tipo="sqlite", ruta=str(destino)))
        except ConexionError as e:
            raise HTTPException(status_code=400, detail=str(e))
        return _escanear_engine(db, engine, f"SQLite · {nombre}", max_filas, "sqlite", str(destino))

    if extension not in SUPPORTED_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Formato no soportado: {extension or 'sin extensión'}")

    content = await file.read()
    if len(content) > MAX_DOCUMENTO_BYTES:
        raise HTTPException(status_code=413, detail="El archivo supera el máximo de 20 MB.")

    if extension in archivos.EXTENSIONES_TABULARES:
        try:
            destino = archivos.tabla_desde_archivo(content, nombre)
            engine = crear_engine(DatosConexion(tipo="sqlite", ruta=str(destino)))
        except Exception:
            logging.exception("Error convirtiendo %s", nombre)
            raise HTTPException(status_code=400, detail="No se pudo leer el archivo como tabla. ¿Está dañado?")
        etiqueta = "CSV" if extension == ".csv" else "Excel"
        return _escanear_engine(db, engine, f"{etiqueta} · {nombre}", max_filas, "sqlite", str(destino))

    try:
        findings = scanner.scan_bytes(content, nombre)
    except UnsupportedFormatError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception:
        logging.exception("Error procesando %s", nombre)
        raise HTTPException(status_code=400, detail="No se pudo leer el archivo. ¿Está dañado?")

    destino = archivos.ruta_nueva(nombre)
    destino.write_bytes(content)
    escaneo = svc.guardar_escaneo_archivo(db, nombre, findings, str(destino))
    return svc.escaneo_a_dict(db, escaneo)


# --------------------------------------------------------------------------- #
# Resultados (siempre enmascarados)
# --------------------------------------------------------------------------- #
def _origen_disponible(escaneo: Escaneo) -> bool:
    """¿Se puede volver a leer el origen para desenmascarar?"""
    if escaneo.id in _conexiones_activas:
        return True
    return bool(escaneo.ruta_local) and Path(escaneo.ruta_local).is_file()


@app.get("/api/escaneos")
def listar_escaneos(db: Session = Depends(get_db)):
    return svc.listar_escaneos(db)


@app.delete("/api/escaneos/{escaneo_id}")
def borrar_escaneo(escaneo_id: int, db: Session = Depends(get_db)):
    escaneo = db.get(Escaneo, escaneo_id)
    if not escaneo:
        raise HTTPException(status_code=404, detail="Escaneo no encontrado.")
    ruta = escaneo.ruta_local
    db.delete(escaneo)
    db.commit()
    engine = _conexiones_activas.pop(escaneo_id, None)
    if engine:
        engine.dispose()
    # Borra la copia que hizo K-Secure (nunca un archivo propio del usuario)
    if ruta and archivos.es_copia_interna(ruta):
        archivos.olvidar_documento(ruta)
        Path(ruta).unlink(missing_ok=True)
    return {"ok": True}


@app.get("/api/hallazgos")
def hallazgos(
    escaneo_id: Optional[int] = None,
    riesgo: Optional[str] = None,
    pagina: int = 1,
    por_pagina: int = 50,
    db: Session = Depends(get_db),
):
    escaneo = svc.obtener_escaneo(db, escaneo_id)
    if not escaneo:
        return {"escaneo": None, "columnas": [], "hallazgos": [], "total": 0}

    por_pagina = max(1, min(por_pagina, 500))
    query = db.query(Hallazgo).filter(Hallazgo.escaneo_id == escaneo.id)
    if riesgo:
        query = query.filter(Hallazgo.riesgo == riesgo)
    total = query.count()
    filas = query.order_by(Hallazgo.id).offset((max(pagina, 1) - 1) * por_pagina).limit(por_pagina).all()

    disponible = _origen_disponible(escaneo)
    return {
        "escaneo": {**svc.escaneo_a_dict(db, escaneo), "conectado": disponible},
        "columnas": svc.columnas_sensibles(db, escaneo),
        "hallazgos": [svc.hallazgo_a_dict(h, disponible) for h in filas],
        "total": total,
    }


# --------------------------------------------------------------------------- #
# Desenmascarar (auditor)
# --------------------------------------------------------------------------- #
class UnmaskRequest(BaseModel):
    password: str
    hallazgo_id: int


def _leer_original(h: Hallazgo) -> Optional[str]:
    escaneo = h.escaneo
    if escaneo.formato == "documento":
        return archivos.releer_documento(escaneo.ruta_local, escaneo.origen_nombre, h.fila_ref, scanner)

    engine = _conexiones_activas.get(escaneo.id)
    if engine is None and escaneo.formato == "sqlite":
        # K-Secure se reinició: se reabre el archivo (en solo lectura)
        engine = crear_engine(DatosConexion(tipo="sqlite", ruta=escaneo.ruta_local))
        _conexiones_activas[escaneo.id] = engine
    return leer_valor(engine, h.tabla, h.columna, h.fila_ref)


@app.post("/api/unmask")
def unmask(req: UnmaskRequest, request: Request, db: Session = Depends(get_db)):
    ip = request.client.host if request.client else "desconocida"
    ahora = time.time()
    _intentos_fallidos[ip] = [t for t in _intentos_fallidos[ip] if ahora - t < BLOQUEO_SEGUNDOS]
    if len(_intentos_fallidos[ip]) >= MAX_INTENTOS_FALLIDOS:
        raise HTTPException(status_code=429, detail="Demasiados intentos fallidos. Espera un minuto.")

    if not svc.verificar_clave_auditor(db, req.password):
        _intentos_fallidos[ip].append(ahora)
        audit_log.warning("Intento fallido de desenmascarar hallazgo=%s ip=%s", req.hallazgo_id, ip)
        raise HTTPException(status_code=401, detail="Contraseña incorrecta.")

    h = db.get(Hallazgo, req.hallazgo_id)
    if not h:
        raise HTTPException(status_code=404, detail="Hallazgo no encontrado.")
    if not h.fila_ref or not _origen_disponible(h.escaneo):
        if h.escaneo.formato == "servidor":
            detalle = "La conexión a esa base ya no está activa. Vuelve a escanearla para ver el dato original."
        else:
            detalle = "El archivo original ya no está disponible. Vuelve a escanearlo para ver el dato original."
        raise HTTPException(status_code=409, detail=detalle)

    try:
        valor = _leer_original(h)
    except Exception:
        logging.exception("Error releyendo hallazgo %s", h.id)
        raise HTTPException(status_code=502, detail="No se pudo leer el dato original.")
    if valor is None:
        raise HTTPException(status_code=404, detail="El dato ya no existe en el origen.")

    audit_log.info("Dato desenmascarado hallazgo=%s ubicacion=%s ip=%s", h.id, h.ubicacion, ip)
    return {"valor": valor}
