﻿; Instalador de K-Secure (Inno Setup 6)
; Lo compila CONSTRUIR_EXE.bat después de generar dist\KSecure.exe

#define AppName "K-Secure"
#define AppVersion "1.1.0"
#define AppPublisher "Equipo K-Secure - Duoc UC"
#define AppExe "KSecure.exe"

[Setup]
AppId={{6F3B2C1E-8A4D-4F2B-9C7E-2D5A1B8E4F60}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
; Se instala para el usuario actual: no pide permisos de administrador
PrivilegesRequired=lowest
DefaultDirName={localappdata}\Programs\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=dist
OutputBaseFilename=KSecure_Instalador
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#AppExe}
UninstallDisplayName={#AppName}
; Al actualizar, si K-Secure está abierto se cierra solo antes de reemplazarlo
CloseApplications=force
RestartApplications=no

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear un acceso directo en el escritorio"; GroupDescription: "Accesos directos:"

[Files]
Source: "dist\{#AppExe}"; DestDir: "{app}"; Flags: ignoreversion
; Bases de ejemplo en Documentos, para que sea fácil encontrarlas
Source: "dist\ejemplos\*.db"; DestDir: "{userdocs}\K-Secure\ejemplos"; Flags: ignoreversion onlyifdoesntexist

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\Bases de ejemplo"; Filename: "{userdocs}\K-Secure\ejemplos"
Name: "{group}\Desinstalar {#AppName}"; Filename: "{uninstallexe}"
Name: "{userdesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "Abrir K-Secure ahora"; Flags: nowait postinstall skipifsilent

[Messages]
spanish.WelcomeLabel2=Este asistente instalará [name/ver] en su equipo.%n%nK-Secure detecta y clasifica datos sensibles (RUT, teléfonos, correos y tarjetas) en bases de datos y documentos, sin modificarlos.
