@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title K-Secure - Generar ejecutable e instalador

echo ============================================================
echo   K-Secure: generando KSecure.exe y el instalador
echo   (la primera vez tarda unos minutos)
echo ============================================================
echo.

rem --- 1. Buscar Python 3.11 / 3.12 / 3.13 ----------------------------------
set "PY="
for %%V in (3.12 3.11 3.13) do (
    if not defined PY (
        py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
    )
)

rem --- 2. Si no hay, instalar Python 3.12 con winget -------------------------
if not defined PY (
    echo No se encontro Python. Instalando Python 3.12...
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        set "PY="%LOCALAPPDATA%\Programs\Python\Python312\python.exe""
    )
)
if not defined PY (
    echo.
    echo [ERROR] No se pudo instalar Python automaticamente.
    echo Descargalo desde https://www.python.org/downloads/ ^(version 3.12^),
    echo marca "Add python.exe to PATH" al instalar y vuelve a ejecutar este archivo.
    pause
    exit /b 1
)
echo Usando: %PY%
echo.

rem --- 3. Entorno aislado e instalacion de dependencias ----------------------
if not exist ".venv_build\Scripts\python.exe" (
    %PY% -m venv .venv_build || goto :error
)
set "VPY=.venv_build\Scripts\python.exe"
"%VPY%" -m pip install --upgrade pip --quiet || goto :error
echo Instalando dependencias...
"%VPY%" -m pip install -r requirements.txt pyinstaller --quiet || goto :error

rem --- 4. Generar el ejecutable ----------------------------------------------
echo Generando el ejecutable...
"%VPY%" build_exe.py || goto :error

rem --- 5. Generar el instalador con Inno Setup ---------------------------------
call :buscar_iscc
if not defined ISCC (
    echo.
    echo Instalando Inno Setup para crear el instalador...
    winget install -e --id JRSoftware.InnoSetup --scope user --accept-package-agreements --accept-source-agreements >nul
    call :buscar_iscc
)
if not defined ISCC (
    rem Si no hay version por usuario, se instala normal (puede pedir permisos)
    winget install -e --id JRSoftware.InnoSetup --accept-package-agreements --accept-source-agreements >nul
    call :buscar_iscc
)
if defined ISCC (
    echo Generando el instalador...
    %ISCC% /Q instalador.iss || goto :error
) else (
    echo [AVISO] No se pudo instalar Inno Setup. Se genero solo KSecure.exe, sin instalador.
)

echo.
echo ============================================================
if exist "dist\KSecure_Instalador.exe" (
    echo   LISTO: dist\KSecure_Instalador.exe  ^<-- este es el que se entrega
)
echo   Ejecutable suelto: dist\KSecure.exe
echo ============================================================
explorer "%~dp0dist"
pause
exit /b 0

:buscar_iscc
set "ISCC="
for %%P in ("%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe") do (
    if not defined ISCC if exist %%P set "ISCC=%%P"
)
exit /b 0

:error
echo.
echo [ERROR] Algo fallo. Copia el mensaje de arriba y revisalo.
pause
exit /b 1
