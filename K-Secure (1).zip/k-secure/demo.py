"""Genera una base de datos SQLite de demostración: examples/empresa_demo.db

Simula el caso que planteó el profesor: un sistema tipo SAP donde los nombres
de columna NO dicen qué contienen (ej. "H14510" guarda el RUT). Sirve para
mostrar que K-Secure clasifica por el CONTENIDO y no por el nombre.

- RUTs con dígito verificador correcto (un ~5% incorrecto a propósito).
- Celulares chilenos (+56 9 XXXX XXXX) y tarjetas que pasan Luhn.

Uso:  python demo.py   →  luego en K-Secure: Base de datos → SQLite → examples/empresa_demo.db
"""

import random
import sqlite3
from pathlib import Path

from faker import Faker

from ksecure.validators.rut import calcular_dv, formatear_rut

fake = Faker("es_CL")
DESTINO = Path(__file__).parent / "examples" / "empresa_demo.db"
PORCENTAJE_DV_INVALIDO = 0.05


def generar_rut() -> str:
    cuerpo = random.randint(5_000_000, 25_000_000)
    dv = calcular_dv(cuerpo)
    if random.random() < PORCENTAJE_DV_INVALIDO:
        dv = random.choice([d for d in "0123456789K" if d != dv])
    return formatear_rut(cuerpo, dv)


def generar_celular() -> str:
    return f"+56 9 {random.randint(1000, 9999)} {random.randint(1000, 9999)}"


def generate_data(num_records: int = 800) -> None:
    DESTINO.parent.mkdir(exist_ok=True)
    DESTINO.unlink(missing_ok=True)
    con = sqlite3.connect(DESTINO)
    con.executescript("""
        CREATE TABLE KNA1 (MANDT TEXT, KUNNR INTEGER PRIMARY KEY, NAME1 TEXT, H14510 TEXT, ZZCOL7 TEXT, TELF2 TEXT);
        CREATE TABLE ZPAGOS (BELNR INTEGER PRIMARY KEY, KUNNR INTEGER, ZZDATA TEXT, WRBTR REAL, SGTXT TEXT);
        CREATE TABLE MARA (MATNR TEXT PRIMARY KEY, MAKTX TEXT, PRECIO INTEGER);
    """)
    clientes = [
        ("100", i, fake.name(), generar_rut(), fake.email(), generar_celular())
        for i in range(1, num_records + 1)
    ]
    con.executemany("INSERT INTO KNA1 VALUES (?,?,?,?,?,?)", clientes)

    pagos = [
        (i, random.randint(1, num_records), fake.credit_card_number(), round(random.uniform(5_000, 500_000)),
         random.choice(["Pago web", "Pago en tienda", f"Contactar a {fake.email()}", "Reembolso"]))
        for i in range(1, num_records + 1)
    ]
    con.executemany("INSERT INTO ZPAGOS VALUES (?,?,?,?,?)", pagos)

    productos = [(f"MAT-{i:05d}", fake.word().capitalize(), random.randint(990, 99_990)) for i in range(1, 201)]
    con.executemany("INSERT INTO MARA VALUES (?,?,?)", productos)
    con.commit()
    con.close()
    print(f"Base de demostración creada en: {DESTINO.resolve()}")


if __name__ == "__main__":
    generate_data()
