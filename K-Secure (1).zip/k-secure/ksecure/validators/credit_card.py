"""Validador de tarjetas de crédito/débito.

La regex encuentra secuencias de 12 a 19 dígitos (con espacios o guiones
opcionales) y luego se aplica el algoritmo de Luhn. Si el número no pasa
Luhn se descarta: así se evitan falsos positivos con folios, códigos de
barra, números de orden, etc.
"""

from ksecure.models import DataType, RiskLevel
from ksecure.validators.base import BaseValidator

# Prefijos (IIN) de las principales marcas: 2 y 5 (Mastercard), 3 (Amex/Diners/JCB),
# 4 (Visa), 6 (Discover/Maestro), 1800 y 2131 (JCB antiguas), 0604 (Maestro).
PREFIJOS_VALIDOS = ("2", "3", "4", "5", "6", "1800", "0604")


def luhn_valido(numero: str) -> bool:
    """Algoritmo de Luhn (ISO/IEC 7812)."""
    total = 0
    for i, digito in enumerate(reversed(numero)):
        n = int(digito)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


class CreditCardValidator(BaseValidator):
    def __init__(self, custom_whitelist=None):
        # Tarjetas de prueba de pasarelas de pago (Stripe, Transbank, etc.)
        default_whitelist = ["4242424242424242", "4000000000000000", "4051885600446623"]
        whitelist = custom_whitelist if custom_whitelist is not None else default_whitelist

        super().__init__(
            name=DataType.TARJETA_CREDITO,
            pattern=r"\b\d(?:[ -]?\d){11,18}\b",
            risk_level=RiskLevel.RESTRINGIDO,
            score=0.85,
            whitelist=whitelist,
            positive_keywords=["tarjeta", "visa", "mastercard", "amex", "crédito", "credito",
                               "débito", "debito", "pago", "card"],
            negative_keywords=["folio", "boleta", "código de barra", "codigo de barra",
                               "orden", "pedido", "teléfono", "telefono"],
        )

    def validate(self, value: str):
        numero = self.normalize(value)
        if not numero.startswith(PREFIJOS_VALIDOS):
            return None
        if not luhn_valido(numero):
            return None
        return True, ["Número válido según algoritmo de Luhn"]

    def mask(self, value: str) -> str:
        """Deja visibles solo los últimos 4 dígitos (estándar PCI-DSS)."""
        numero = self.normalize(value)
        return "****-****-****-" + numero[-4:]

    def normalize(self, value: str) -> str:
        return value.replace(" ", "").replace("-", "").strip()
