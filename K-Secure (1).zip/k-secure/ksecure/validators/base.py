"""Clase base para todos los validadores de K-Secure.

Cada validador hijo define:
- una expresión regular (qué "parece" ser el dato),
- una validación propia (Módulo 11, Luhn, etc.) en `validate()`,
- palabras clave positivas/negativas para ajustar la confianza según el contexto,
- cómo enmascarar y normalizar el valor.
"""

import re
from typing import List, Optional, Tuple

from ksecure.models import Confidence, DataType, Finding, RiskLevel

# Cuántos caracteres antes del hallazgo se miran para buscar palabras clave.
CONTEXT_WINDOW = 40
POSITIVE_BOOST = 0.10
NEGATIVE_PENALTY = 0.25


def score_to_confidence(score: float) -> Confidence:
    if score >= 0.85:
        return Confidence.ALTA
    if score >= 0.60:
        return Confidence.MEDIA
    return Confidence.BAJA


class BaseValidator:
    def __init__(
        self,
        name: DataType,
        pattern: str,
        risk_level: RiskLevel,
        score: float,
        whitelist: Optional[List[str]] = None,
        positive_keywords: Optional[List[str]] = None,
        negative_keywords: Optional[List[str]] = None,
        invalid_risk_level: RiskLevel = RiskLevel.INTERNO,
        flags: int = 0,
    ):
        self.name = name
        self.pattern = re.compile(pattern, flags)
        self.risk_level = risk_level
        self.invalid_risk_level = invalid_risk_level
        self.score = score
        self.whitelist = {self._clean(w) for w in (whitelist or [])}
        self.positive_keywords = positive_keywords or []
        self.negative_keywords = negative_keywords or []

    # ------------------------------------------------------------------ #
    # Métodos que las clases hijas pueden sobrescribir
    # ------------------------------------------------------------------ #
    def validate(self, value: str) -> Optional[Tuple[bool, List[str]]]:
        """Valida el valor detectado por la regex.

        Retorna:
            (es_valido, motivos)  -> el hallazgo se reporta.
            None                  -> falso positivo, se descarta.
        """
        return True, []

    def score_adjustment(self, value: str) -> float:
        """Ajuste extra del score según el propio valor (ej: prefijo +56)."""
        return 0.0

    def mask(self, value: str) -> str:
        raise NotImplementedError("Debe implementarse en la clase hija")

    def normalize(self, value: str) -> str:
        return value.strip()

    # ------------------------------------------------------------------ #
    # Lógica común
    # ------------------------------------------------------------------ #
    @staticmethod
    def _clean(value: str) -> str:
        return value.strip().replace(" ", "").lower()

    def is_suppressed(self, value: str) -> bool:
        return self._clean(value) in self.whitelist

    def is_already_masked(self, value: str) -> bool:
        return value.count("*") > 2 or value.lower().count("x") > 2

    def _context_score(self, context: str) -> Tuple[float, List[str]]:
        """Ajusta el score según palabras clave cercanas al hallazgo."""
        context = context.lower()
        score = self.score
        reasons: List[str] = []

        positivas = [k for k in self.positive_keywords if k in context]
        negativas = [k for k in self.negative_keywords if k in context]

        if positivas:
            score += POSITIVE_BOOST
            reasons.append(f"Contexto positivo: '{positivas[0]}'")
        if negativas:
            score -= NEGATIVE_PENALTY
            reasons.append(f"Contexto negativo: '{negativas[0]}'")

        return max(0.0, min(1.0, score)), reasons

    def find(self, content: str, source: str, context_hint: str = "") -> List[Finding]:
        """Busca el dato en `content`.

        `context_hint` es texto extra que se considera parte del contexto
        (por ejemplo, el nombre de la columna en una base de datos).
        """
        findings: List[Finding] = []
        if not content:
            return findings

        for match in self.pattern.finditer(content):
            raw_value = match.group(0)

            if self.is_suppressed(raw_value) or self.is_already_masked(raw_value):
                continue

            result = self.validate(raw_value)
            if result is None:
                continue
            is_valid, reasons = result

            window = content[max(0, match.start() - CONTEXT_WINDOW):match.start()]
            score, context_reasons = self._context_score(f"{context_hint} {window}")
            score = max(0.0, min(1.0, score + self.score_adjustment(raw_value)))
            if not is_valid:
                score = min(score, 0.5)

            findings.append(
                Finding(
                    source=source,
                    data_type=self.name,
                    risk_level=self.risk_level if is_valid else self.invalid_risk_level,
                    confidence=score_to_confidence(score),
                    confidence_score=score,
                    is_valid=is_valid,
                    raw_value=raw_value,
                    normalized_value=self.normalize(raw_value),
                    masked_value=self.mask(raw_value),
                    reasons=reasons + context_reasons,
                )
            )

        return findings
