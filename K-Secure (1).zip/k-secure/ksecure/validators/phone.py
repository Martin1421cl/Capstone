"""Validador de teléfonos móviles chilenos (+56 9 XXXX XXXX)."""

import re

from ksecure.models import DataType, RiskLevel
from ksecure.validators.base import BaseValidator


class PhoneValidator(BaseValidator):
    def __init__(self, custom_whitelist=None):
        default_whitelist = ["+56900000000", "+56999999999"]
        whitelist = custom_whitelist if custom_whitelist is not None else default_whitelist

        super().__init__(
            name=DataType.TELEFONO_MOVIL,
            # Con prefijo (+56 9 1234 5678, 56912345678) o sin él (912345678)
            pattern=r"(?<![\d+])\+?56[ -]?9[ -]?\d{4}[ -]?\d{4}\b|\b9\d{8}\b",
            risk_level=RiskLevel.CONFIDENCIAL,
            score=0.75,
            whitelist=whitelist,
            positive_keywords=["teléfono", "telefono", "celular", "móvil", "movil",
                               "fono", "whatsapp", "contacto"],
            negative_keywords=["folio", "boleta", "código", "codigo", "orden", "pedido"],
        )

    def score_adjustment(self, value: str) -> float:
        # Con el prefijo de país es casi seguro que se trata de un teléfono
        return 0.10 if "56" in value[:3] else 0.0

    def is_suppressed(self, value: str) -> bool:
        return self.normalize(value) in {self.normalize(w) for w in self.whitelist}

    def mask(self, value: str) -> str:
        """+56 9 **** 5678"""
        numero = self.normalize(value)
        return f"+56 9 **** {numero[-4:]}"

    def normalize(self, value: str) -> str:
        """Formato estándar E.164: +56912345678"""
        digitos = re.sub(r"\D", "", value)
        if not digitos.startswith("56"):
            digitos = "56" + digitos
        return "+" + digitos
