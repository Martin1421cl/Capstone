import re

from ksecure.models import DataType, RiskLevel
from ksecure.validators.base import BaseValidator


class EmailValidator(BaseValidator):
    def __init__(self, custom_whitelist=None):
        # Ejemplos documentados que no representan un riesgo real
        default_whitelist = ["test@example.com", "usuario@prueba.cl", "ejemplo@duoc.cl"]
        whitelist = custom_whitelist if custom_whitelist is not None else default_whitelist

        super().__init__(
            name=DataType.CORREO_ELECTRONICO,
            pattern=r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
            risk_level=RiskLevel.INTERNO,
            score=0.90,
            whitelist=whitelist,
            positive_keywords=["correo", "email", "e-mail", "mail", "contacto"],
            flags=re.IGNORECASE,
        )

    def mask(self, value: str) -> str:
        """Deja visibles las 2 primeras letras del usuario y el dominio."""
        usuario, dominio = value.split("@", 1)
        usuario_enmascarado = usuario[:2] + "****" if len(usuario) > 2 else "****"
        return f"{usuario_enmascarado}@{dominio}"

    def normalize(self, value: str) -> str:
        return value.strip().lower()
