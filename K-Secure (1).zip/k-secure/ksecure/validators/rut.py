"""Validador de RUT (Rol Único Tributario) chileno.

Combina dos capas, tal como se definió en el Informe de Fase 1:

1. Expresión regular que reconoce los formatos habituales de escritura
   de un RUT: con puntos de miles (12.345.678-5) o sin ellos (12345678-5),
   siempre con guion antes del dígito verificador.
2. Validación matemática del dígito verificador con el algoritmo Módulo 11.
   Un RUT con DV incorrecto se reporta igual, pero como inválido y con
   menor nivel de riesgo (puede ser un error de digitación o un falso positivo).
"""

from ksecure.models import DataType, RiskLevel
from ksecure.validators.base import BaseValidator


def calcular_dv(cuerpo: int) -> str:
    """Calcula el dígito verificador de un RUT con el algoritmo Módulo 11."""
    suma = 0
    multiplicador = 2
    for digito in reversed(str(cuerpo)):
        suma += int(digito) * multiplicador
        multiplicador = multiplicador + 1 if multiplicador < 7 else 2

    resto = 11 - (suma % 11)
    if resto == 11:
        return "0"
    if resto == 10:
        return "K"
    return str(resto)


def formatear_rut(cuerpo: int, dv: str) -> str:
    """12345678, '5' -> '12.345.678-5'"""
    return f"{cuerpo:,}".replace(",", ".") + f"-{dv}"


class RutValidator(BaseValidator):
    def __init__(self, custom_whitelist=None):
        # RUTs de ejemplo muy usados en documentación y pruebas
        default_whitelist = ["11.111.111-1", "12.345.678-5"]
        whitelist = custom_whitelist if custom_whitelist is not None else default_whitelist

        super().__init__(
            name=DataType.RUT,
            # Con puntos: 1-2 dígitos + .ddd + .ddd  |  Sin puntos: 6 a 8 dígitos
            pattern=r"\b(?:\d{1,2}(?:\.\d{3}){2}|\d{6,8})-[\dkK]\b",
            risk_level=RiskLevel.RESTRINGIDO,
            score=0.85,
            whitelist=whitelist,
            positive_keywords=["rut", "run", "rol único", "rol unico", "cédula", "cedula",
                               "identificación", "identificacion", "documento"],
            negative_keywords=["folio", "boleta", "factura", "código", "codigo",
                               "orden", "pedido", "sku", "serie"],
        )

    def validate(self, value: str):
        cuerpo_str, dv = value.replace(".", "").upper().split("-")
        dv_esperado = calcular_dv(int(cuerpo_str))
        if dv == dv_esperado:
            return True, ["Dígito verificador válido (Módulo 11)"]
        return False, [f"Dígito verificador inválido: se esperaba '{dv_esperado}'"]

    def mask(self, value: str) -> str:
        """Muestra solo los últimos 3 dígitos del cuerpo y el DV: **.***.678-5"""
        cuerpo, dv = value.replace(".", "").split("-")
        return f"**.***.{cuerpo[-3:]}-{dv.upper()}"

    def normalize(self, value: str) -> str:
        """12.345.678-k -> 12345678-K"""
        return value.replace(".", "").upper().strip()
