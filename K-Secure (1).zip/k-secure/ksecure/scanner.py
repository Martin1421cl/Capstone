"""Motor de escaneo K-Secure.

Punto único de entrada para escanear cualquier fuente: archivos en disco,
archivos subidos por la API (bytes en memoria) o registros de la base de datos.
"""

import csv
import io
from pathlib import Path
from typing import Iterable

import docx
import pandas as pd
import pdfplumber
from pptx import Presentation

from ksecure.models import Finding
from ksecure.validators.base import BaseValidator
from ksecure.validators.credit_card import CreditCardValidator
from ksecure.validators.email import EmailValidator
from ksecure.validators.phone import PhoneValidator
from ksecure.validators.rut import RutValidator

SUPPORTED_EXTENSIONS = {".csv", ".txt", ".docx", ".xlsx", ".xls", ".pptx", ".pdf"}


class UnsupportedFormatError(ValueError):
    pass


class KSecureScanner:
    """Orquesta los validadores sobre una o más fuentes de datos."""

    def __init__(self, validators: list[BaseValidator] | None = None):
        self.validators = validators or [
            RutValidator(),
            PhoneValidator(),
            CreditCardValidator(),
            EmailValidator(),
        ]

    # ------------------------------------------------------------------ #
    # Entradas
    # ------------------------------------------------------------------ #
    def scan_file(self, filepath: str | Path) -> list[Finding]:
        """Escanea un archivo en disco."""
        path = Path(filepath)
        return self.scan_bytes(path.read_bytes(), path.name)

    def scan_bytes(self, content: bytes, filename: str) -> list[Finding]:
        """Escanea un archivo en memoria (por ejemplo, uno subido por la API)."""
        extension = Path(filename).suffix.lower()
        if extension not in SUPPORTED_EXTENSIONS:
            raise UnsupportedFormatError(f"Formato no soportado: {extension or 'sin extensión'}")

        stream = io.BytesIO(content)
        if extension == ".csv":
            return self._scan_csv(content, filename)
        if extension == ".txt":
            return self._scan_text(content.decode("utf-8", errors="ignore"), filename)
        if extension == ".docx":
            return self._scan_docx(stream, filename)
        if extension in (".xlsx", ".xls"):
            return self._scan_excel(stream, filename)
        if extension == ".pptx":
            return self._scan_pptx(stream, filename)
        return self._scan_pdf(stream, filename)

    def scan_record(self, record: dict, source: str) -> list[Finding]:
        """Escanea una fila de base de datos. El nombre de la columna se usa como contexto."""
        findings: list[Finding] = []
        for column, value in record.items():
            if value is None or str(value).strip() == "":
                continue
            findings.extend(
                self._scan_text(str(value), f"{source}:{column}", context_hint=column)
            )
        return findings

    # ------------------------------------------------------------------ #
    # Extractores por formato
    # ------------------------------------------------------------------ #
    def _scan_csv(self, content: bytes, filename: str) -> list[Finding]:
        findings: list[Finding] = []
        text = content.decode("utf-8-sig", errors="ignore")
        reader = csv.DictReader(io.StringIO(text))
        for row_idx, row in enumerate(reader, start=2):
            for column, value in row.items():
                if not value:
                    continue
                findings.extend(
                    self._scan_text(value, f"{filename}:{column}:fila {row_idx}", context_hint=column or "")
                )
        return findings

    def _scan_docx(self, stream, filename: str) -> list[Finding]:
        findings: list[Finding] = []
        doc = docx.Document(stream)
        for i, paragraph in enumerate(doc.paragraphs, start=1):
            if paragraph.text.strip():
                findings.extend(self._scan_text(paragraph.text, f"{filename}:párrafo {i}"))
        for t, table in enumerate(doc.tables, start=1):
            for r, row in enumerate(table.rows, start=1):
                row_text = " | ".join(cell.text for cell in row.cells)
                if row_text.strip(" |"):
                    findings.extend(self._scan_text(row_text, f"{filename}:tabla {t} fila {r}"))
        return findings

    def _scan_excel(self, stream, filename: str) -> list[Finding]:
        findings: list[Finding] = []
        sheets = pd.read_excel(stream, sheet_name=None, dtype=str)
        for sheet_name, df in sheets.items():
            for row_num, (_, row) in enumerate(df.iterrows(), start=2):
                for col_name, value in row.items():
                    if pd.notna(value) and str(value).strip():
                        source = f"{filename}:hoja '{sheet_name}':col '{col_name}':fila {row_num}"
                        findings.extend(self._scan_text(str(value), source, context_hint=str(col_name)))
        return findings

    def _scan_pptx(self, stream, filename: str) -> list[Finding]:
        findings: list[Finding] = []
        prs = Presentation(stream)
        for i, slide in enumerate(prs.slides, start=1):
            for shape in slide.shapes:
                texto = getattr(shape, "text", "").strip()
                if texto:
                    findings.extend(self._scan_text(texto, f"{filename}:diapositiva {i}"))
        return findings

    def _scan_pdf(self, stream, filename: str) -> list[Finding]:
        findings: list[Finding] = []
        with pdfplumber.open(stream) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                texto = page.extract_text()
                if texto:
                    findings.extend(self._scan_text(texto, f"{filename}:página {i}"))
        return findings

    def scan_value(self, value: str, source: str, context_hint: str = "") -> list[Finding]:
        """Escanea un valor suelto (por ejemplo, una celda de una base de datos)."""
        return self._scan_text(value, source, context_hint=context_hint)

    # ------------------------------------------------------------------ #
    def _scan_text(self, content: str, source: str, context_hint: str = "") -> list[Finding]:
        """Pasa el texto por todos los validadores activos."""
        findings: list[Finding] = []
        for validator in self.validators:
            findings.extend(validator.find(content, source, context_hint=context_hint))
        return findings

    def scan_many(self, filepaths: Iterable[str | Path]) -> list[Finding]:
        findings: list[Finding] = []
        for path in filepaths:
            findings.extend(self.scan_file(path))
        return findings
