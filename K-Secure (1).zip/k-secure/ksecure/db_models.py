"""Tablas de la base interna de K-Secure."""

from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from ksecure.database import Base


class Configuracion(Base):
    __tablename__ = "configuracion"

    clave = Column(String, primary_key=True)
    valor = Column(Text, nullable=False)


class Escaneo(Base):
    __tablename__ = "escaneos"

    id = Column(Integer, primary_key=True)
    origen_tipo = Column(String, nullable=False)        # "bd" o "archivo"
    origen_nombre = Column(String, nullable=False)      # ej: "SQLite · compras.db" o "informe.docx"
    fecha = Column(DateTime, default=datetime.now, nullable=False)
    tablas_revisadas = Column(Integer, default=0)
    filas_revisadas = Column(Integer, default=0)
    filas_por_tabla = Column(Text, default="{}")   # JSON {tabla: filas revisadas}
    formato = Column(String)        # "sqlite", "servidor" o "documento": cómo volver a leer el origen
    ruta_local = Column(Text)       # copia local del archivo (para desenmascarar después de reiniciar)

    hallazgos = relationship("Hallazgo", back_populates="escaneo", cascade="all, delete-orphan")


class Hallazgo(Base):
    """Un dato sensible encontrado. NUNCA guarda el valor original."""

    __tablename__ = "hallazgos"

    id = Column(Integer, primary_key=True)
    escaneo_id = Column(Integer, ForeignKey("escaneos.id", ondelete="CASCADE"), index=True, nullable=False)
    tabla = Column(String)              # solo para escaneos de BD
    columna = Column(String)            # solo para escaneos de BD
    ubicacion = Column(String)          # texto legible: "clientes.rut · fila 12" o "informe.docx:párrafo 3"
    fila_ref = Column(Text)             # JSON con la clave de la fila, para volver a leerla (desenmascarar)
    tipo = Column(String, nullable=False)
    riesgo = Column(String, nullable=False, index=True)
    confianza = Column(Integer, nullable=False)
    es_valido = Column(Boolean, nullable=False)
    valor_enmascarado = Column(String, nullable=False)
    motivos = Column(Text, default="")

    escaneo = relationship("Escaneo", back_populates="hallazgos")
