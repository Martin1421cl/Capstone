"""Manejo de archivos subidos.

- CSV y Excel se convierten en una base SQLite (una tabla por hoja) dentro de
  la carpeta de datos de K-Secure. Desde ahí se escanean igual que cualquier
  base de datos: clasificación por columna y desenmascarado por fila.
- Word, PDF, PowerPoint y TXT se guardan como copia local. Para desenmascarar
  se vuelve a leer el archivo y se busca el mismo hallazgo.

Las copias quedan en la carpeta de datos (no se mandan a ningún lado) y se
eliminan al borrar el escaneo desde el dashboard.
"""

import io
import json
import re
import sqlite3
import uuid
from collections import OrderedDict
from pathlib import Path
from typing import Optional

import pandas as pd

from ksecure.models import Finding
from ksecure.paths import data_dir
from ksecure.scanner import KSecureScanner

EXTENSIONES_TABULARES = {".csv", ".xlsx", ".xls"}


def carpeta_subidas() -> Path:
    carpeta = data_dir() / "archivos_subidos"
    carpeta.mkdir(exist_ok=True)
    return carpeta


def ruta_nueva(nombre: str, extension: Optional[str] = None) -> Path:
    base = Path(nombre)
    return carpeta_subidas() / f"{uuid.uuid4().hex[:8]}_{base.stem}{extension or base.suffix}"


def es_copia_interna(ruta: str) -> bool:
    """True si el archivo es una copia hecha por K-Secure (se puede borrar)."""
    try:
        return Path(ruta).resolve().is_relative_to(carpeta_subidas().resolve())
    except (OSError, ValueError):
        return False


# --------------------------------------------------------------------------- #
# CSV / Excel -> SQLite
# --------------------------------------------------------------------------- #
def _nombre_tabla(texto: str, usados: set) -> str:
    nombre = re.sub(r"\W+", "_", texto.strip(), flags=re.UNICODE).strip("_") or "tabla"
    candidato, i = nombre, 2
    while candidato.lower() in usados:
        candidato, i = f"{nombre}_{i}", i + 1
    usados.add(candidato.lower())
    return candidato


def _leer_csv(contenido: bytes) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "latin-1"):
        try:
            texto = contenido.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    # sep=None detecta solo si el separador es "," o ";" (Excel en español usa ";")
    return pd.read_csv(io.StringIO(texto), sep=None, engine="python", dtype=str, keep_default_na=False)


def tabla_desde_archivo(contenido: bytes, nombre: str) -> Path:
    """Convierte un CSV/Excel en una base SQLite y retorna su ruta."""
    extension = Path(nombre).suffix.lower()
    usados: set = set()
    if extension == ".csv":
        hojas = {_nombre_tabla(Path(nombre).stem, usados): _leer_csv(contenido)}
    else:
        libro = pd.read_excel(io.BytesIO(contenido), sheet_name=None, dtype=str)
        hojas = {_nombre_tabla(str(hoja), usados): df.fillna("") for hoja, df in libro.items()}

    destino = ruta_nueva(nombre, ".db")
    con = sqlite3.connect(destino)
    try:
        for tabla, df in hojas.items():
            df.columns = [str(c).strip() or f"columna_{i + 1}" for i, c in enumerate(df.columns)]
            df.to_sql(tabla, con, index=False)
        con.commit()
    finally:
        con.close()
    return destino


# --------------------------------------------------------------------------- #
# Documentos (Word, PDF, PowerPoint, TXT)
# --------------------------------------------------------------------------- #
def referencias_documento(findings: list[Finding]) -> list[str]:
    """Para cada hallazgo, una referencia que permite encontrarlo de nuevo en el archivo."""
    vistos: dict = {}
    refs = []
    for f in findings:
        clave = (f.source, f.data_type.value)
        n = vistos.get(clave, 0)
        vistos[clave] = n + 1
        refs.append(json.dumps({"fuente": f.source, "tipo": f.data_type.value, "n": n}))
    return refs


_cache_documentos: "OrderedDict[str, list[Finding]]" = OrderedDict()


def releer_documento(ruta: str, nombre: str, fila_ref: str, scanner: KSecureScanner) -> Optional[str]:
    """Vuelve a escanear el documento y devuelve el valor original del hallazgo."""
    if ruta not in _cache_documentos:
        _cache_documentos[ruta] = scanner.scan_bytes(Path(ruta).read_bytes(), nombre)
        if len(_cache_documentos) > 5:  # mantiene en memoria solo los últimos documentos
            _cache_documentos.popitem(last=False)
    ref = json.loads(fila_ref)
    coincidencias = [f for f in _cache_documentos[ruta]
                     if f.source == ref["fuente"] and f.data_type.value == ref["tipo"]]
    return coincidencias[ref["n"]].raw_value if ref["n"] < len(coincidencias) else None


def olvidar_documento(ruta: str) -> None:
    _cache_documentos.pop(ruta, None)
