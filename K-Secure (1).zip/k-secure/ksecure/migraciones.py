"""Migraciones de la base interna de K-Secure.

Cuando una versión nueva agrega o cambia tablas, el cliente ya tiene una base
interna creada con la versión anterior. `create_all` solo crea tablas que no
existen: NO agrega columnas nuevas. Este módulo lo resuelve.

Cómo agregar un cambio en una versión futura:
  1. Modifica el modelo en db_models.py.
  2. Agrega una función `_vN` abajo y súmala a MIGRACIONES.
  3. Cada migración debe poder correr más de una vez sin romper nada.
"""

import logging

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine

log = logging.getLogger("ksecure.migraciones")


def _agregar_columna(conn, tabla: str, columna: str, tipo: str) -> None:
    existentes = {c["name"] for c in inspect(conn).get_columns(tabla)}
    if columna not in existentes:
        conn.execute(text(f'ALTER TABLE "{tabla}" ADD COLUMN "{columna}" {tipo}'))
        log.info("Migración: columna %s.%s agregada", tabla, columna)


def _v1(conn) -> None:
    """v1.1: los archivos subidos se pueden desenmascarar (se guarda su copia local)."""
    _agregar_columna(conn, "escaneos", "formato", "VARCHAR")
    _agregar_columna(conn, "escaneos", "ruta_local", "TEXT")


MIGRACIONES = [(1, _v1)]


def migrar(engine: Engine) -> int:
    """Aplica las migraciones pendientes. Retorna la versión final del esquema."""
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE IF NOT EXISTS configuracion (clave VARCHAR PRIMARY KEY, valor TEXT NOT NULL)"))
        fila = conn.execute(text("SELECT valor FROM configuracion WHERE clave = 'schema_version'")).first()
        version = int(fila[0]) if fila else 0

        for numero, funcion in MIGRACIONES:
            if numero > version:
                funcion(conn)
                version = numero

        conn.execute(text("DELETE FROM configuracion WHERE clave = 'schema_version'"))
        conn.execute(text("INSERT INTO configuracion (clave, valor) VALUES ('schema_version', :v)"), {"v": str(version)})
    return version
