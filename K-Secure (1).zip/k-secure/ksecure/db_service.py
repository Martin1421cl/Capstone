"""Lógica entre el motor de escaneo y la base interna de K-Secure.

Regla clave: en la base interna y hacia el navegador solo viajan valores
ENMASCARADOS. El valor original se vuelve a leer desde la base del cliente
solo cuando un auditor lo pide con contraseña.
"""

import hashlib
import json
import hmac
import secrets
from collections import Counter, defaultdict
from typing import Optional

from sqlalchemy import func
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from ksecure.conexiones import escanear_bd
from ksecure.db_models import Configuracion, Escaneo, Hallazgo
from ksecure.models import Finding
from ksecure.scanner import KSecureScanner

ORDEN_RIESGO = {"Restringido": 0, "Confidencial": 1, "Interno": 2, "Público": 3}
_LOTE = 1000  # hallazgos que se insertan por commit

# --------------------------------------------------------------------------- #
# Contraseña de auditor (se guarda solo el hash, nunca la clave)
# --------------------------------------------------------------------------- #
_ITERACIONES = 200_000


def _hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERACIONES).hex()


def hay_clave_auditor(db: Session) -> bool:
    return db.get(Configuracion, "auditor_hash") is not None


def definir_clave_auditor(db: Session, password: str) -> None:
    salt = secrets.token_bytes(16)
    db.merge(Configuracion(clave="auditor_salt", valor=salt.hex()))
    db.merge(Configuracion(clave="auditor_hash", valor=_hash(password, salt)))
    db.commit()


def verificar_clave_auditor(db: Session, password: str) -> bool:
    salt = db.get(Configuracion, "auditor_salt")
    guardado = db.get(Configuracion, "auditor_hash")
    if not salt or not guardado:
        return False
    return hmac.compare_digest(_hash(password, bytes.fromhex(salt.valor)), guardado.valor)


# --------------------------------------------------------------------------- #
# Guardar escaneos
# --------------------------------------------------------------------------- #
def _nuevo_hallazgo(escaneo_id: int, f: Finding, ubicacion: str, tabla=None, columna=None, fila_ref=None) -> Hallazgo:
    return Hallazgo(
        escaneo_id=escaneo_id,
        tabla=tabla,
        columna=columna,
        ubicacion=ubicacion,
        fila_ref=fila_ref,
        tipo=f.data_type.value,
        riesgo=f.risk_level.value,
        confianza=round(f.confidence_score * 100),
        es_valido=f.is_valid,
        valor_enmascarado=f.masked_value,
        motivos=" · ".join(f.reasons),
    )


def guardar_escaneo_bd(db: Session, engine: Engine, descripcion: str,
                       scanner: KSecureScanner, max_filas: int,
                       formato: str = "servidor", ruta_local: Optional[str] = None) -> Escaneo:
    escaneo = Escaneo(origen_tipo="bd", origen_nombre=descripcion, formato=formato, ruta_local=ruta_local)
    db.add(escaneo)
    db.commit()

    stats: dict = {}
    lote: list[Hallazgo] = []
    for celda in escanear_bd(engine, scanner, max_filas, stats):
        lote.append(_nuevo_hallazgo(escaneo.id, celda.finding, celda.ubicacion,
                                    celda.tabla, celda.columna, celda.fila_ref))
        if len(lote) >= _LOTE:
            db.add_all(lote)
            db.commit()
            lote = []
    db.add_all(lote)
    escaneo.tablas_revisadas = stats.get("tablas", 0)
    escaneo.filas_revisadas = stats.get("filas", 0)
    escaneo.filas_por_tabla = json.dumps(stats.get("por_tabla", {}))
    db.commit()
    db.refresh(escaneo)
    return escaneo


def guardar_escaneo_archivo(db: Session, filename: str, findings: list[Finding],
                            ruta_local: Optional[str] = None) -> Escaneo:
    from ksecure.archivos import referencias_documento

    escaneo = Escaneo(origen_tipo="archivo", origen_nombre=filename, tablas_revisadas=0,
                      filas_revisadas=0, formato="documento", ruta_local=ruta_local)
    db.add(escaneo)
    db.commit()
    refs = referencias_documento(findings) if ruta_local else [None] * len(findings)
    db.add_all(_nuevo_hallazgo(escaneo.id, f, f.source, fila_ref=r) for f, r in zip(findings, refs))
    db.commit()
    db.refresh(escaneo)
    return escaneo


# --------------------------------------------------------------------------- #
# Consultas para el dashboard
# --------------------------------------------------------------------------- #
def resumen(db: Session, escaneo_id: int) -> dict:
    conteo = dict(
        db.query(Hallazgo.riesgo, func.count())
        .filter(Hallazgo.escaneo_id == escaneo_id)
        .group_by(Hallazgo.riesgo)
        .all()
    )
    return {
        "total": sum(conteo.values()),
        "Restringido": conteo.get("Restringido", 0),
        "Confidencial": conteo.get("Confidencial", 0),
        "Interno": conteo.get("Interno", 0),
    }


def escaneo_a_dict(db: Session, e: Escaneo) -> dict:
    return {
        "id": e.id,
        "origen_tipo": e.origen_tipo,
        "origen_nombre": e.origen_nombre,
        "fecha": e.fecha.strftime("%d-%m-%Y %H:%M"),
        "tablas_revisadas": e.tablas_revisadas,
        "filas_revisadas": e.filas_revisadas,
        "resumen": resumen(db, e.id),
    }


def listar_escaneos(db: Session) -> list[dict]:
    return [escaneo_a_dict(db, e) for e in db.query(Escaneo).order_by(Escaneo.id.desc()).limit(50)]


def columnas_sensibles(db: Session, escaneo: Escaneo) -> list[dict]:
    """Clasificación por columna: lo que alimentaría las reglas de un DLP.

    Para cada tabla.columna con hallazgos indica el tipo de dato predominante,
    el riesgo más alto y en qué % de las filas revisadas aparece.
    """
    if escaneo.origen_tipo != "bd":
        return []

    filas = (
        db.query(Hallazgo.tabla, Hallazgo.columna, Hallazgo.tipo, Hallazgo.riesgo,
                 Hallazgo.es_valido, Hallazgo.fila_ref, Hallazgo.ubicacion)
        .filter(Hallazgo.escaneo_id == escaneo.id)
        .all()
    )
    grupos: dict = defaultdict(lambda: {"tipos": Counter(), "riesgos": Counter(), "filas": set(), "invalidos": 0})
    for tabla, columna, tipo, riesgo, valido, fila_ref, ubicacion in filas:
        g = grupos[(tabla, columna)]
        g["tipos"][tipo] += 1
        g["riesgos"][riesgo] += 1
        g["filas"].add(fila_ref or ubicacion)
        g["invalidos"] += 0 if valido else 1

    total_filas = json.loads(escaneo.filas_por_tabla or "{}")
    resultado = []
    for (tabla, columna), g in grupos.items():
        riesgo_max = min(g["riesgos"], key=lambda r: ORDEN_RIESGO.get(r, 9))
        revisadas = total_filas.get(tabla) or len(g["filas"])
        resultado.append({
            "tabla": tabla,
            "columna": columna,
            "tipo": " + ".join(t for t, _ in g["tipos"].most_common()),
            "riesgo": riesgo_max,
            "hallazgos": sum(g["tipos"].values()),
            "invalidos": g["invalidos"],
            "cobertura": round(100 * len(g["filas"]) / revisadas) if revisadas else 0,
        })
    resultado.sort(key=lambda c: (ORDEN_RIESGO.get(c["riesgo"], 9), -c["hallazgos"]))
    return resultado


def hallazgo_a_dict(h: Hallazgo, se_puede_desenmascarar: bool) -> dict:
    return {
        "id": h.id,
        "tipo": h.tipo,
        "riesgo": h.riesgo,
        "confianza": h.confianza,
        "es_valido": h.es_valido,
        "valor_enmascarado": h.valor_enmascarado,
        "origen": h.ubicacion,
        "motivos": h.motivos.split(" · ") if h.motivos else [],
        "desenmascarable": se_puede_desenmascarar and bool(h.fila_ref),
    }


def obtener_escaneo(db: Session, escaneo_id: Optional[int]) -> Optional[Escaneo]:
    if escaneo_id:
        return db.get(Escaneo, escaneo_id)
    return db.query(Escaneo).order_by(Escaneo.id.desc()).first()
