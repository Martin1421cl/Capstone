"""Conexión de SOLO LECTURA a la base de datos del cliente.

K-Secure descubre automáticamente las tablas y columnas, lee las filas y
pasa cada celda por el motor de escaneo. Nunca escribe en la base del cliente.
"""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Optional

import sqlite3

from sqlalchemy import MetaData, Table, and_, create_engine, event, inspect, literal_column, select
from sqlalchemy.engine import URL, Engine

from ksecure.models import Finding
from ksecure.scanner import KSecureScanner

TIPOS_BD = {
    "sqlite": "SQLite (archivo .db)",
    "postgresql": "PostgreSQL",
    "mysql": "MySQL / MariaDB",
    "sqlserver": "SQL Server",
    "oracle": "Oracle",
}

_PUERTOS = {"postgresql": 5432, "mysql": 3306, "sqlserver": 1433, "oracle": 1521}


class ConexionError(Exception):
    pass


@dataclass
class DatosConexion:
    tipo: str
    ruta: str = ""          # SQLite
    host: str = "localhost"
    puerto: Optional[int] = None
    base: str = ""          # nombre de la BD (en Oracle: service name)
    usuario: str = ""
    password: str = ""

    def descripcion(self) -> str:
        nombre = TIPOS_BD.get(self.tipo, self.tipo)
        if self.tipo == "sqlite":
            return f"{nombre} · {Path(self.ruta).name}"
        return f"{nombre} · {self.base}@{self.host}"


def crear_engine(datos: DatosConexion) -> Engine:
    """Crea la conexión en modo lectura y verifica que funcione."""
    tipo = datos.tipo

    if tipo == "sqlite":
        ruta = Path(datos.ruta.strip().strip('"'))
        if not ruta.is_file():
            raise ConexionError(f"No existe el archivo: {ruta}")
        uri = ruta.resolve().as_uri() + "?mode=ro"
        engine = create_engine("sqlite://", creator=lambda: sqlite3.connect(uri, uri=True, check_same_thread=False))

    elif tipo in _PUERTOS:
        drivers = {
            "postgresql": "postgresql+psycopg2",
            "mysql": "mysql+pymysql",
            "sqlserver": "mssql+pymssql",
            "oracle": "oracle+oracledb",
        }
        url = URL.create(
            drivername=drivers[tipo],
            username=datos.usuario or None,
            password=datos.password or None,
            host=datos.host or "localhost",
            port=datos.puerto or _PUERTOS[tipo],
            database=None if tipo == "oracle" else (datos.base or None),
            query={"service_name": datos.base} if tipo == "oracle" and datos.base else {},
        )
        connect_args = {}
        if tipo == "postgresql":
            connect_args = {"options": "-c default_transaction_read_only=on", "connect_timeout": 10}
        try:
            engine = create_engine(url, connect_args=connect_args, pool_pre_ping=True)
        except ImportError as e:
            raise ConexionError(f"Falta el driver para {TIPOS_BD[tipo]}: {e.name}") from e

        if tipo == "mysql":
            @event.listens_for(engine, "connect")
            def _solo_lectura(dbapi_conn, _):
                with dbapi_conn.cursor() as cur:
                    cur.execute("SET SESSION TRANSACTION READ ONLY")
    else:
        raise ConexionError(f"Tipo de base de datos no soportado: {tipo}")

    try:
        with engine.connect():
            pass
    except Exception as e:  # noqa: BLE001 — mostramos el error del motor tal cual
        engine.dispose()
        raise ConexionError(f"No se pudo conectar: {str(e).splitlines()[0][:200]}") from e
    return engine


def listar_tablas(engine: Engine) -> list[str]:
    return sorted(inspect(engine).get_table_names())


def _tabla(engine: Engine, nombre: str) -> Table:
    return Table(nombre, MetaData(), autoload_with=engine)


def _clave_fila(engine: Engine, tabla: Table) -> list[str]:
    """Columnas que identifican una fila. Si no hay PK y es SQLite se usa rowid."""
    pk = [c.name for c in tabla.primary_key.columns]
    if pk:
        return pk
    if engine.dialect.name == "sqlite":
        return ["rowid"]
    return []


@dataclass
class ResultadoCelda:
    tabla: str
    columna: str
    fila_ref: Optional[str]
    ubicacion: str
    finding: Finding


def escanear_bd(engine: Engine, scanner: KSecureScanner, max_filas: int, stats: dict) -> Iterator[ResultadoCelda]:
    """Recorre todas las tablas/columnas y entrega cada hallazgo."""
    stats.setdefault("tablas", 0)
    stats.setdefault("filas", 0)
    stats.setdefault("por_tabla", {})

    for nombre in listar_tablas(engine):
        tabla = _tabla(engine, nombre)
        clave = _clave_fila(engine, tabla)
        columnas = [c for c in tabla.columns]

        cols_select = list(columnas)
        if clave == ["rowid"]:
            cols_select = [literal_column("rowid").label("__rowid__")] + cols_select

        stats["tablas"] += 1
        stats["por_tabla"][nombre] = 0
        with engine.connect() as conn:
            filas = conn.execute(select(*cols_select).limit(max_filas))
            for n, fila in enumerate(filas, start=1):
                stats["filas"] += 1
                stats["por_tabla"][nombre] = n
                datos = fila._mapping
                if clave == ["rowid"]:
                    ref = {"rowid": datos["__rowid__"]}
                elif clave:
                    ref = {k: datos[k] for k in clave}
                else:
                    ref = None
                fila_ref = json.dumps(ref, default=str) if ref else None

                for col in columnas:
                    valor = datos[col.name]
                    if valor is None or isinstance(valor, (bytes, bytearray, memoryview)):
                        continue
                    texto = str(valor).strip()
                    if not texto:
                        continue
                    ubicacion = f"{nombre}.{col.name} · fila {n}"
                    for f in scanner.scan_value(texto, ubicacion, context_hint=col.name):
                        yield ResultadoCelda(nombre, col.name, fila_ref, ubicacion, f)


def leer_valor(engine: Engine, tabla_nombre: str, columna: str, fila_ref: str) -> Optional[str]:
    """Vuelve a leer UNA celda de la base del cliente (para desenmascarar)."""
    tabla = _tabla(engine, tabla_nombre)
    ref = json.loads(fila_ref)
    if list(ref) == ["rowid"]:
        condicion = literal_column("rowid") == ref["rowid"]
    else:
        condicion = and_(*[tabla.c[k] == v for k, v in ref.items()])
    with engine.connect() as conn:
        valor = conn.execute(select(tabla.c[columna]).where(condicion).limit(1)).scalar()
    return None if valor is None else str(valor)
