"""Rutas de la aplicación, válidas tanto en desarrollo como dentro del .exe."""

import os
import sys
from pathlib import Path


def resource_dir() -> Path:
    """Carpeta con los archivos del programa (index.html, etc.).

    Dentro del .exe de PyInstaller los archivos se descomprimen en sys._MEIPASS.
    """
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent.parent


def data_dir() -> Path:
    """Carpeta donde K-Secure guarda su base interna y las bases subidas.

    Windows: %LOCALAPPDATA%\\KSecure   ·   Linux/Mac: ~/.ksecure
    Se puede cambiar con la variable de entorno KSECURE_DATA_DIR.
    """
    if os.getenv("KSECURE_DATA_DIR"):
        path = Path(os.environ["KSECURE_DATA_DIR"])
    elif os.name == "nt" and os.getenv("LOCALAPPDATA"):
        path = Path(os.environ["LOCALAPPDATA"]) / "KSecure"
    else:
        path = Path.home() / ".ksecure"
    path.mkdir(parents=True, exist_ok=True)
    return path
