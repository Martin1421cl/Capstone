"""Base de datos INTERNA de K-Secure.

Aquí K-Secure guarda su configuración y los resultados de los escaneos
(solo valores enmascarados). Es un archivo SQLite en la carpeta de datos,
así que no hay que instalar ningún motor de base de datos.

Las bases del cliente NO se guardan aquí: se leen en modo lectura
(ver ksecure/conexiones.py).
"""

import os

from dotenv import load_dotenv
from sqlalchemy import create_engine, event
from sqlalchemy.orm import declarative_base, sessionmaker

from ksecure.paths import data_dir

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL") or f"sqlite:///{data_dir() / 'ksecure_interno.db'}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)

if DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def _sqlite_fk(dbapi_conn, _):
        dbapi_conn.execute("PRAGMA foreign_keys=ON")

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
