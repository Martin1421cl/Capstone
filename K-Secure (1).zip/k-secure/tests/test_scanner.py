from pathlib import Path

import pytest

from ksecure.scanner import KSecureScanner, UnsupportedFormatError

SAMPLE = Path(__file__).parent.parent / "examples" / "sample_data.csv"


def test_scan_csv_de_ejemplo_detecta_rut_y_marca_dv_invalido():
    findings = KSecureScanner().scan_file(SAMPLE)
    assert findings, "El CSV de ejemplo debería tener hallazgos"
    ruts = [f for f in findings if f.data_type.value == "RUT"]
    assert any(f.is_valid for f in ruts)
    assert any(not f.is_valid and f.risk_level.value == "Interno" for f in ruts)


def test_scan_record_usa_nombre_de_columna_como_contexto():
    scanner = KSecureScanner()
    con_columna = scanner.scan_record({"rut": "18.123.456-3"}, "fila 1")[0]
    sin_contexto = scanner._scan_text("18.123.456-3", "fila 1")[0]
    assert con_columna.confidence_score > sin_contexto.confidence_score


def test_formato_no_soportado():
    with pytest.raises(UnsupportedFormatError):
        KSecureScanner().scan_bytes(b"abc", "archivo.exe")
