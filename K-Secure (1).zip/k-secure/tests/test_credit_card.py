from ksecure.validators.credit_card import CreditCardValidator, luhn_valido


class TestLuhn:
    def test_numero_valido(self):
        assert luhn_valido("4111111111111111")

    def test_numero_invalido(self):
        assert not luhn_valido("4111111111111112")


class TestCreditCardValidator:
    def setup_method(self):
        self.validator = CreditCardValidator()

    def test_detecta_con_guiones(self):
        findings = self.validator.find("Pago con tarjeta 4111-1111-1111-1111", "test")
        assert len(findings) == 1
        assert findings[0].normalized_value == "4111111111111111"

    def test_descarta_numero_que_no_pasa_luhn(self):
        # Un folio largo no debe confundirse con una tarjeta
        assert self.validator.find("Folio 1234567890123", "test") == []
        assert self.validator.find("Tarjeta 4111 1111 1111 1112", "test") == []

    def test_mascara_solo_ultimos_4(self):
        f = self.validator.find("Visa 4111111111111111", "test")[0]
        assert f.masked_value == "****-****-****-1111"

    def test_tarjeta_de_prueba_en_whitelist(self):
        assert self.validator.find("4242 4242 4242 4242", "test") == []
