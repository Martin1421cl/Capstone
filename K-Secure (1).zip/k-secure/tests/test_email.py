from ksecure.validators.email import EmailValidator


class TestEmailValidator:
    def setup_method(self):
        self.validator = EmailValidator()

    def test_detecta_y_normaliza(self):
        findings = self.validator.find("Escribir a Juan.Perez@Empresa.CL", "test")
        assert findings[0].normalized_value == "juan.perez@empresa.cl"

    def test_mascara(self):
        f = self.validator.find("maria.g@gmail.com", "test")[0]
        assert f.masked_value == "ma****@gmail.com"

    def test_whitelist(self):
        assert self.validator.find("test@example.com", "test") == []

    def test_correo_sin_arroba_no_se_detecta(self):
        assert self.validator.find("ana.rojas.gmail.com", "test") == []
