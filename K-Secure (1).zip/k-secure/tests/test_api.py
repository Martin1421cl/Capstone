import sqlite3

import pytest
from fastapi.testclient import TestClient

import main
from ksecure.database import Base, engine
from main import app

client = TestClient(app)
CLAVE = "clave-de-prueba"


@pytest.fixture(autouse=True)
def entorno_limpio():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    main._intentos_fallidos.clear()
    main._conexiones_activas.clear()
    client.post("/api/configurar", json={"password": CLAVE})
    yield


@pytest.fixture
def bd_cliente(tmp_path):
    """Base de un 'cliente' con nombres de columna que no dicen nada."""
    ruta = tmp_path / "cliente.db"
    con = sqlite3.connect(ruta)
    con.executescript("""
        CREATE TABLE KNA1 (KUNNR INTEGER PRIMARY KEY, H14510 TEXT, ZZCOL7 TEXT, MONTO INTEGER);
        INSERT INTO KNA1 VALUES (1, '18.123.456-3', 'juan.perez@empresa.cl', 100);
        INSERT INTO KNA1 VALUES (2, '7.654.321-6', '+56 9 8765 4321', 200);
        CREATE TABLE SIN_PK (dato TEXT);
        INSERT INTO SIN_PK VALUES ('Tarjeta 4111 1111 1111 1111');
    """)
    con.commit()
    con.close()
    return str(ruta)


def test_configurar_solo_una_vez():
    assert client.get("/api/estado").json()["configurado"] is True
    r = client.post("/api/configurar", json={"password": "otra-clave"})
    assert r.status_code == 409


def test_escanear_bd_detecta_rut_en_columna_con_nombre_raro(bd_cliente):
    r = client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente})
    assert r.status_code == 200
    assert r.json()["resumen"]["total"] == 5

    d = client.get("/api/hallazgos").json()
    columnas = {(c["tabla"], c["columna"]): c for c in d["columnas"]}
    assert columnas[("KNA1", "H14510")]["tipo"] == "RUT"
    assert columnas[("KNA1", "H14510")]["cobertura"] == 100


def test_hallazgos_nunca_envian_el_dato_original(bd_cliente):
    client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente})
    texto = client.get("/api/hallazgos").text
    for original in ["18.123.456-3", "juan.perez@empresa.cl", "8765 4321", "4111 1111 1111 1111"]:
        assert original not in texto


def test_unmask_relee_la_bd_con_y_sin_pk(bd_cliente):
    client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente})
    hallazgos = client.get("/api/hallazgos").json()["hallazgos"]
    valores = set()
    for h in hallazgos:
        r = client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": h["id"]})
        assert r.status_code == 200
        valores.add(r.json()["valor"])
    assert "18.123.456-3" in valores
    assert "Tarjeta 4111 1111 1111 1111" in valores  # tabla sin PK (usa rowid)


def test_unmask_clave_incorrecta_y_bloqueo(bd_cliente):
    client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente})
    hid = client.get("/api/hallazgos").json()["hallazgos"][0]["id"]
    assert client.post("/api/unmask", json={"password": "1234", "hallazgo_id": hid}).status_code == 401
    for _ in range(5):
        client.post("/api/unmask", json={"password": "x", "hallazgo_id": hid})
    assert client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": hid}).status_code == 429


def test_unmask_sin_conexion_activa(bd_cliente):
    from ksecure.database import SessionLocal
    from ksecure.db_models import Escaneo

    eid = client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente}).json()["id"]
    hid = client.get("/api/hallazgos").json()["hallazgos"][0]["id"]
    main._conexiones_activas.clear()  # simula que se cerró K-Secure

    # Un archivo SQLite se reabre solo
    assert client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": hid}).status_code == 200

    # Una base de servidor (PostgreSQL, etc.) no: no se guardan sus credenciales
    db = SessionLocal()
    e = db.get(Escaneo, eid)
    e.formato, e.ruta_local = "servidor", None
    db.commit()
    db.close()
    main._conexiones_activas.clear()
    assert client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": hid}).status_code == 409


def test_conexion_es_solo_lectura(bd_cliente):
    from sqlalchemy import text
    from ksecure.conexiones import DatosConexion, crear_engine

    eng = crear_engine(DatosConexion(tipo="sqlite", ruta=bd_cliente))
    with pytest.raises(Exception):
        with eng.begin() as conn:
            conn.execute(text("DELETE FROM KNA1"))


def test_subir_base_sqlite(bd_cliente):
    with open(bd_cliente, "rb") as fh:
        r = client.post("/api/scan", files={"file": ("cliente.db", fh, "application/octet-stream")})
    assert r.status_code == 200
    assert r.json()["origen_tipo"] == "bd"


def test_subir_archivo_que_no_es_sqlite():
    r = client.post("/api/scan", files={"file": ("falso.db", b"no soy una base", "application/octet-stream")})
    assert r.status_code == 400


def test_scan_documento_permite_desenmascarar():
    contenido = "Cliente RUT 7.654.321-6, correo maria.g@gmail.com".encode()
    r = client.post("/api/scan", files={"file": ("datos.txt", contenido, "text/plain")})
    assert r.json()["resumen"]["total"] == 2
    valores = set()
    for h in client.get("/api/hallazgos").json()["hallazgos"]:
        assert h["desenmascarable"] is True
        valores.add(client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": h["id"]}).json()["valor"])
    assert valores == {"7.654.321-6", "maria.g@gmail.com"}


def test_csv_se_escanea_como_tabla():
    csv = "nombre;H14510;contacto\nAna;7.654.321-6;ana@empresa.cl\nLuis;;+56 9 8765 4321\n".encode("latin-1")
    r = client.post("/api/scan", files={"file": ("clientes.csv", csv, "text/csv")})
    assert r.status_code == 200
    d = client.get("/api/hallazgos").json()
    columnas = {c["columna"]: c for c in d["columnas"]}
    assert columnas["H14510"]["tipo"] == "RUT"
    assert columnas["H14510"]["cobertura"] == 50
    rut = next(h for h in d["hallazgos"] if h["tipo"] == "RUT")
    assert client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": rut["id"]}).json()["valor"] == "7.654.321-6"


def test_archivo_desenmascarable_tras_reiniciar():
    client.post("/api/scan", files={"file": ("a.csv", b"rut\n7.654.321-6\n", "text/csv")})
    hid = client.get("/api/hallazgos").json()["hallazgos"][0]["id"]
    main._conexiones_activas.clear()  # simula que se cerró K-Secure
    r = client.post("/api/unmask", json={"password": CLAVE, "hallazgo_id": hid})
    assert r.json()["valor"] == "7.654.321-6"


def test_borrar_escaneo_elimina_la_copia_del_archivo():
    from ksecure.archivos import carpeta_subidas

    antes = set(carpeta_subidas().iterdir())
    eid = client.post("/api/scan", files={"file": ("b.txt", b"RUT 7.654.321-6", "text/plain")}).json()["id"]
    assert len(set(carpeta_subidas().iterdir()) - antes) == 1
    client.delete(f"/api/escaneos/{eid}")
    assert set(carpeta_subidas().iterdir()) == antes


def test_migracion_agrega_columnas_a_base_antigua(tmp_path):
    from sqlalchemy import create_engine, inspect, text
    from ksecure.migraciones import migrar

    eng = create_engine(f"sqlite:///{tmp_path / 'vieja.db'}")
    with eng.begin() as conn:  # esquema de la versión 1.0
        conn.execute(text("CREATE TABLE escaneos (id INTEGER PRIMARY KEY, origen_tipo VARCHAR, origen_nombre VARCHAR)"))
    assert migrar(eng) == 1
    assert migrar(eng) == 1  # correrla dos veces no rompe nada
    columnas = {c["name"] for c in inspect(eng).get_columns("escaneos")}
    assert {"formato", "ruta_local"} <= columnas


def test_formato_no_soportado():
    r = client.post("/api/scan", files={"file": ("virus.exe", b"MZ", "application/octet-stream")})
    assert r.status_code == 400


def test_ruta_sqlite_inexistente():
    r = client.post("/api/bd/probar", json={"tipo": "sqlite", "ruta": "/no/existe.db"})
    assert r.status_code == 400


def test_borrar_escaneo(bd_cliente):
    eid = client.post("/api/bd/escanear", json={"tipo": "sqlite", "ruta": bd_cliente}).json()["id"]
    assert client.delete(f"/api/escaneos/{eid}").status_code == 200
    assert client.get("/api/escaneos").json() == []
