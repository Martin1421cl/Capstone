import os
import tempfile

# Las pruebas usan una carpeta de datos temporal: no tocan la instalación real.
os.environ["KSECURE_DATA_DIR"] = tempfile.mkdtemp(prefix="ksecure_test_")
