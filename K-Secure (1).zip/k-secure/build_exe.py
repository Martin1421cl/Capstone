"""Genera dist/KSecure.exe (Windows) o dist/KSecure (Linux/Mac) con PyInstaller.

Uso:  python build_exe.py      (lo llama CONSTRUIR_EXE.bat)
El ejecutable debe generarse en el mismo sistema operativo donde se usará.
"""

import os
import shutil
from pathlib import Path

import PyInstaller.__main__

AQUI = Path(__file__).resolve().parent
SEP = os.pathsep  # ';' en Windows, ':' en Linux/Mac

PyInstaller.__main__.run([
    str(AQUI / "ksecure_app.py"),
    "--name", "KSecure",
    "--onefile",
    "--console",
    "--noconfirm",
    "--clean",
    "--distpath", str(AQUI / "dist"),
    "--workpath", str(AQUI / "build"),
    "--specpath", str(AQUI / "build"),
    "--paths", str(AQUI),
    "--add-data", f"{AQUI / 'index.html'}{SEP}.",
    # Servidor web
    "--collect-submodules", "uvicorn",
    "--hidden-import", "main",
    # Motores de base de datos soportados
    "--collect-submodules", "sqlalchemy.dialects",
    "--hidden-import", "psycopg2",
    "--hidden-import", "pymysql",
    "--hidden-import", "pymssql",
    "--collect-submodules", "oracledb",
    "--collect-submodules", "cryptography",   # oracledb (modo thin) la necesita
    # Lectores de documentos (incluyen plantillas/datos internos)
    "--collect-data", "docx",
    "--collect-data", "pptx",
    "--collect-data", "pdfminer",
    # No se necesitan dentro del .exe
    "--exclude-module", "faker",
    "--exclude-module", "pytest",
    "--exclude-module", "tkinter",
])

# Copia las bases de ejemplo junto al ejecutable para poder hacer la demo
ejemplos = AQUI / "dist" / "ejemplos"
ejemplos.mkdir(parents=True, exist_ok=True)
for db in (AQUI / "examples").glob("*.db"):
    shutil.copy2(db, ejemplos / db.name)

print("\nListo. Ejecutable en:", AQUI / "dist")
