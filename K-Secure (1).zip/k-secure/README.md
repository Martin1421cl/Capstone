# K-Secure — Sistema de Clasificación de Datos Sensibles

Prototipo inicial (Fase 1 → avance para Fase 2) del motor de escaneo
K-Secure, adaptado al contexto chileno: detecta **RUT**, **teléfonos
móviles (+56 9)**, **correos** y **tarjetas de crédito** dentro de fuentes de datos, valida el RUT con el
algoritmo **Módulo 11** y las tarjetas con **Luhn**, y genera reportes de clasificación por nivel
de riesgo (Público / Interno / Confidencial / Restringido) pensados
como insumo de entrada para una herramienta DLP.

Construido desde cero en Python, sin depender de librerías de
clasificación de terceros. La estructura de validadores (regex +
reglas de validación + scoring por contexto) toma como referencia
conceptual el proyecto open source [FerretScan](https://github.com/awslabs/ferret-scan)
de AWS Labs — no se reutiliza su código, que está en Go y orientado a
identificadores de EE.UU. (SSN, etc.), sino su enfoque de diseño.

## Usarlo como programa (sin instalar nada)

1. Doble clic en **`CONSTRUIR_EXE.bat`** (si falta Python o Inno Setup, los instala solo).
2. Se genera **`dist\KSecure_Instalador.exe`**: es lo que se le entrega al cliente.
3. El instalador crea accesos directos (menú Inicio y escritorio), deja bases de prueba en
   `Documentos\K-Secure\ejemplos` y aparece en "Agregar o quitar programas". No pide permisos de administrador.
4. Al abrir K-Secure se abre el navegador con el dashboard.
5. La primera vez pide crear la **contraseña de auditor**.
6. **Base de datos** → elige el tipo (SQLite, PostgreSQL, MySQL, SQL Server u Oracle),
   completa los datos y presiona **Escanear**. También se puede subir un `.db` o un documento.

Para cerrar K-Secure, cierra la ventana negra. Los resultados quedan guardados en
`%LOCALAPPDATA%\KSecure` y solo contienen valores **enmascarados**.

> El instalador también se puede generar en GitHub: pestaña **Actions → Generar KSecure.exe → Run workflow**,
> y se descarga desde "Artifacts".

## Cómo funciona

```
Base del cliente ──(solo lectura)──► K-Secure descubre tablas y columnas
                                      │
                                      ▼
                     Cada celda pasa por los validadores
          (regex → Módulo 11 / Luhn → whitelist → contexto del nombre de columna)
                                      │
                                      ▼
   Base interna de K-Secure: hallazgos ENMASCARADOS + clasificación por columna
                                      │
                                      ▼
   Dashboard: "KNA1.H14510 → RUT, Restringido, 100% de las filas"
```

- **Solo lectura**: K-Secure nunca modifica la base del cliente (en PostgreSQL y MySQL
  la sesión se abre en modo *read only*; en SQLite el archivo se abre como `mode=ro`).
- **Clasificación por columna**: detecta columnas sensibles aunque su nombre no lo diga
  (el caso "H14510" de SAP). Es el insumo para las reglas de un DLP.
- **Archivos**: CSV y Excel se analizan como tablas (con clasificación por columna);
  Word, PDF, PowerPoint y TXT como documentos.
- **Desenmascarar**: los resultados guardan solo valores enmascarados. Si un auditor pide
  el original (con contraseña), K-Secure lo vuelve a leer desde el origen: la base del
  cliente o la copia del archivo subido (guardada en la carpeta de datos y eliminada al
  borrar el escaneo). Para bases de servidor (PostgreSQL, etc.) hay que volver a escanear
  después de cerrar K-Secure, porque sus contraseñas no se guardan. Tras 5 intentos
  fallidos se bloquea 1 minuto, y todo queda registrado en el log.
- **Actualizaciones**: la base interna se migra sola al abrir una versión nueva
  (`ksecure/migraciones.py`), así el cliente no pierde sus escaneos.

## Estructura del proyecto

```
k-secure/
├── ksecure_app.py             # Punto de entrada del .exe (abre el navegador)
├── main.py                    # API FastAPI
├── index.html                 # Dashboard
├── CONSTRUIR_EXE.bat          # Genera dist\KSecure.exe y dist\KSecure_Instalador.exe
├── instalador.iss             # Script de Inno Setup (instalador)
├── build_exe.py               # Configuración de PyInstaller
├── escanear.py                # Escaneo de archivos por terminal → output/reporte.json y .csv
├── demo.py                    # Crea examples/empresa_demo.db (tablas tipo SAP)
├── ksecure/
│   ├── conexiones.py          # Conexión de solo lectura a SQLite/PostgreSQL/MySQL/SQL Server/Oracle
│   ├── archivos.py            # CSV/Excel → tabla; copia de documentos para desenmascarar
│   ├── migraciones.py         # Actualiza la base interna entre versiones
│   ├── scanner.py             # KSecureScanner: motor único (archivos, uploads y BD)
│   ├── db_service.py          # Guarda escaneos, clasificación por columna, clave de auditor
│   ├── db_models.py           # Tablas de la base interna
│   ├── database.py            # Base interna (SQLite en la carpeta de datos)
│   ├── paths.py               # Rutas válidas en desarrollo y dentro del .exe
│   ├── models.py / report.py
│   └── validators/            # rut (Módulo 11), credit_card (Luhn), phone, email
├── examples/                  # sample_data.csv y bases .db de prueba
└── tests/                     # pytest
```

## Desarrollo

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt

python demo.py                 # crea examples/empresa_demo.db
uvicorn main:app --reload      # http://127.0.0.1:8000
pytest -v                      # pruebas (no necesitan ningún motor de BD)
```

Escanear archivos desde la terminal:

```powershell
python escanear.py examples/sample_data.csv
```

## API

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/estado` | Si ya se configuró la clave de auditor y tipos de BD soportados |
| POST | `/api/configurar` | Primer uso: define la clave de auditor |
| POST | `/api/bd/probar` | Prueba una conexión y lista las tablas |
| POST | `/api/bd/escanear` | Escanea todas las tablas de una BD |
| POST | `/api/scan` | Sube un documento o una base `.db` y la escanea |
| GET | `/api/escaneos` | Lista de escaneos realizados |
| GET | `/api/hallazgos` | Hallazgos enmascarados + clasificación por columna (paginado) |
| POST | `/api/unmask` | Valor original de un hallazgo (requiere clave de auditor) |
| DELETE | `/api/escaneos/{id}` | Borra los resultados de un escaneo |

## Próximos pasos

- [ ] Validadores para nombres, direcciones y cuentas bancarias.
- [ ] Guardar los accesos a `/api/unmask` en una tabla de auditoría (hoy van al log).
- [ ] Exportar la clasificación por columna en un formato que un DLP pueda importar.
- [ ] Documentar formalmente el marco de niveles de clasificación
      (Público/Interno/Confidencial/Restringido) citando el whitepaper OEA/AWS
      y la Política de Duoc UC.
