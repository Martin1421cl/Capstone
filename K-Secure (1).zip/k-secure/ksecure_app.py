"""Punto de entrada de K-Secure como aplicación (lo que ejecuta KSecure.exe).

Levanta el servidor en este computador (solo accesible localmente) y abre el
navegador con el dashboard. Para cerrar K-Secure basta con cerrar esta ventana.
"""

import os
import socket
import sys
import threading
import time
import urllib.request
import webbrowser


def puerto_libre(preferido: int) -> int:
    for puerto in range(preferido, preferido + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", puerto)) != 0:
                return puerto
    raise RuntimeError("No hay puertos libres entre %d y %d" % (preferido, preferido + 19))


def abrir_navegador_cuando_este_listo(url: str) -> None:
    for _ in range(60):
        try:
            urllib.request.urlopen(url + "api/estado", timeout=1)
            webbrowser.open(url)
            return
        except Exception:
            time.sleep(0.5)


def main() -> None:
    if sys.stdout:
        sys.stdout.reconfigure(line_buffering=True)
    import uvicorn

    from ksecure.paths import data_dir
    from main import app

    puerto = puerto_libre(int(os.getenv("KSECURE_PORT", "8000")))
    url = f"http://127.0.0.1:{puerto}/"

    print("=" * 60)
    print("  K-Secure - Detección de Datos Sensibles")
    print("=" * 60)
    print(f"  Dashboard:  {url}")
    print(f"  Datos en:   {data_dir()}")
    print("  Para cerrar K-Secure, cierra esta ventana.")
    print("=" * 60)

    threading.Thread(target=abrir_navegador_cuando_este_listo, args=(url,), daemon=True).start()
    # host 127.0.0.1: el dashboard NO queda expuesto a la red, solo a este computador
    uvicorn.run(app, host="127.0.0.1", port=puerto, log_level="warning")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        print(f"\nError al iniciar K-Secure: {e}")
        if getattr(sys, "frozen", False):
            input("Presiona Enter para cerrar...")
        raise
